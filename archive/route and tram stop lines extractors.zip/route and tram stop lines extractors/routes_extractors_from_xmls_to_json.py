import xml.etree.ElementTree as ET
import json
import re


def extract_line_number(filename):
    match = re.search(r'(\d+)\.xml$', filename)
    return str(int(match.group(1))) if match else None


def parse_xml_routes(xml_files):
    tram_routes = {}
    for xml_file in xml_files:
        line_number = extract_line_number(xml_file)
        tree = ET.parse(xml_file)
        root = tree.getroot()
        for wariant in root.findall('.//wariant'):
            czasy = wariant.find('.//czasy')
            if czasy is not None:
                przystanki = czasy.findall('.//przystanek')
                tram_stops = [przystanek.get('nazwa') for przystanek in przystanki]
                # ensure the tram line number is in the dictionary and add the route if it's not a duplicate
                if line_number not in tram_routes:
                    tram_routes[line_number] = []
                if tram_stops not in tram_routes[line_number]:
                    tram_routes[line_number].append(tram_stops)
    return tram_routes


def write_to_json(tram_routes, output_file):
    with open(output_file, 'w', encoding='utf-8') as file:
        json.dump(tram_routes, file, ensure_ascii=False, indent=4)


def parse_xml_only_main_routes(xml_files):
    tram_routes = {}
    for xml_file in xml_files:
        line_number = extract_line_number(xml_file)
        tree = ET.parse(xml_file)
        root = tree.getroot()
        for wariant in root.findall('.//wariant'):
            czasy = wariant.find('.//czasy')
            if czasy is not None:
                przystanki = czasy.findall('.//przystanek')
                tram_stops = [przystanek.get('nazwa') for przystanek in przystanki]
                # check if any stop contains 'zajezdnia', skip this route if true
                if any('zajezdnia' in stop.lower() for stop in tram_stops):
                    continue
                # ensure the tram line number is in the dictionary and add the route if it's not a duplicate
                if line_number not in tram_routes:
                    tram_routes[line_number] = []
                if tram_stops not in tram_routes[line_number]:
                    tram_routes[line_number].append(tram_stops)
    return tram_routes


with open('xml_files.txt', 'r') as file:  # list of files paths to read from
    xml_files = file.read().splitlines()
routes = parse_xml_routes(xml_files)
write_to_json(routes, 'tram_routes.json')
